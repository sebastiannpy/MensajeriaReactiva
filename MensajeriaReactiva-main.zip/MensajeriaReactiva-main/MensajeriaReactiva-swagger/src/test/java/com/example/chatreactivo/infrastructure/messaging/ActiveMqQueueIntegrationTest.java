package com.example.chatreactivo.infrastructure.messaging;

import com.example.chatreactivo.application.service.MensajeRealtimeStream;
import com.example.chatreactivo.domain.model.Mensaje;
import com.example.chatreactivo.domain.ports.out.MensajeQueuePort;
import com.example.chatreactivo.infrastructure.adapter.in.messaging.ActiveMqMensajeConsumer;
import com.example.chatreactivo.infrastructure.adapter.out.messaging.ActiveMqMensajePublisher;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.jms.ConnectionFactory;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import reactor.test.StepVerifier;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringJUnitConfig
@ContextConfiguration(classes = ActiveMqQueueIntegrationTest.TestConfig.class)
@TestPropertySource(properties = "app.messaging.queue-name=chat.mensajes.test.queue")
class ActiveMqQueueIntegrationTest {

    @Autowired
    private MensajeQueuePort mensajeQueuePort;

    @Autowired
    private MensajeRealtimeStream mensajeRealtimeStream;

    @Test
    void debePublicarYConsumirMensajesPorActiveMq() {
        UUID remitente = UUID.randomUUID();
        UUID receptor = UUID.randomUUID();

        Mensaje mensaje = new Mensaje(
                UUID.randomUUID(),
                remitente,
                receptor,
                "mensaje de prueba ActiveMQ",
                OffsetDateTime.now()
        );

        StepVerifier.create(mensajeRealtimeStream.escucharPorUsuario(receptor).next())
                .then(() -> mensajeQueuePort.publicar(mensaje).block(Duration.ofSeconds(5)))
                .assertNext(recibido -> {
                    assertEquals(mensaje.getId(), recibido.getId());
                    assertEquals(mensaje.getContenido(), recibido.getContenido());
                    assertEquals(remitente, recibido.getRemitenteId());
                    assertEquals(receptor, recibido.getReceptorId());
                })
                .verifyComplete();
    }

    @Configuration
    @EnableJms
    static class TestConfig {

        @Bean
        ConnectionFactory connectionFactory() {
            return new ActiveMQConnectionFactory("vm://test-broker?broker.persistent=false&broker.useShutdownHook=false");
        }

        @Bean
        JmsTemplate jmsTemplate(ConnectionFactory connectionFactory) {
            return new JmsTemplate(connectionFactory);
        }

        @Bean
        DefaultJmsListenerContainerFactory jmsListenerContainerFactory(ConnectionFactory connectionFactory) {
            DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
            factory.setConnectionFactory(connectionFactory);
            return factory;
        }

        @Bean
        ObjectMapper objectMapper() {
            return new ObjectMapper().registerModule(new JavaTimeModule());
        }

        @Bean
        MensajeRealtimeStream mensajeRealtimeStream() {
            return new MensajeRealtimeStream();
        }

        @Bean
        MensajeQueuePort mensajeQueuePort(JmsTemplate jmsTemplate,
                                          ObjectMapper objectMapper,
                                          @Value("${app.messaging.queue-name}") String queueName) {
            return new ActiveMqMensajePublisher(jmsTemplate, objectMapper, queueName);
        }

        @Bean
        ActiveMqMensajeConsumer activeMqMensajeConsumer(ObjectMapper objectMapper,
                                                        MensajeRealtimeStream mensajeRealtimeStream) {
            return new ActiveMqMensajeConsumer(objectMapper, mensajeRealtimeStream);
        }
    }
}
