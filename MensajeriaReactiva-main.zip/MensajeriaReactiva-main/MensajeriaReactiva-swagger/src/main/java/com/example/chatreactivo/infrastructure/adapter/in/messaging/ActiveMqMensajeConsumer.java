package com.example.chatreactivo.infrastructure.adapter.in.messaging;

import com.example.chatreactivo.application.service.MensajeRealtimeStream;
import com.example.chatreactivo.domain.model.Mensaje;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class ActiveMqMensajeConsumer {

    private static final Logger log = LoggerFactory.getLogger(ActiveMqMensajeConsumer.class);

    private final ObjectMapper objectMapper;
    private final MensajeRealtimeStream mensajeRealtimeStream;

    public ActiveMqMensajeConsumer(ObjectMapper objectMapper, MensajeRealtimeStream mensajeRealtimeStream) {
        this.objectMapper = objectMapper;
        this.mensajeRealtimeStream = mensajeRealtimeStream;
    }

    @JmsListener(destination = "${app.messaging.queue-name}")
    public void consumir(String payload) {
        try {
            Mensaje mensaje = objectMapper.readValue(payload, Mensaje.class);
            mensajeRealtimeStream.emitir(mensaje);
            log.info("Mensaje consumido de ActiveMQ. id={}, remitente={}, receptor={}",
                    mensaje.getId(), mensaje.getRemitenteId(), mensaje.getReceptorId());
        } catch (JsonProcessingException e) {
            log.error("Mensaje inválido en cola ActiveMQ: {}", payload, e);
        }
    }
}
