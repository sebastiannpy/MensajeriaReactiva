# Chat Reactivo Hexagonal

Proyecto backend en Spring Boot WebFlux con arquitectura hexagonal.

## Requisitos
- Java 21
- PostgreSQL
- Maven

## Base de datos esperada
Tablas:
- roles
- usuarios
- mensajes

## Swagger
- http://localhost:8081/swagger-ui.html

## Endpoints principales
- POST /api/auth/login
- POST /api/usuarios
- PUT /api/usuarios/{id}
- PATCH /api/usuarios/{id}/inactivar
- CRUD /api/roles
- POST /api/mensajes
- GET /api/mensajes?usuario1=...&usuario2=...
- GET /api/mensajes/stream/{usuarioId}

## Cola de mensajería (ActiveMQ)
- Tecnología implementada: ActiveMQ (JMS)
- Cola configurada: `chat.mensajes.queue`
- Ubicación del broker: embebido en la misma aplicación (`vm://chat-broker`), en memoria.

### Flujo
- `MensajeService` guarda el mensaje en BD y lo publica en la cola ActiveMQ.
- `ActiveMqMensajeConsumer` consume el mensaje desde la cola y lo emite al stream SSE.

### Prueba de funcionamiento
- Ejecutar:
  - `mvn -Dtest=ActiveMqQueueIntegrationTest test`
- La prueba verifica extremo a extremo:
  - Publicación en cola (`ActiveMqMensajePublisher`)
  - Consumo desde cola (`ActiveMqMensajeConsumer`)
  - Recepción reactiva en `MensajeRealtimeStream`
